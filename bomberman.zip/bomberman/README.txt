Starte main_game_final, um das Spiel in der beendeten Version zu spielen.
Das Spiel muss mit einem Codeinterpreter wie Visual Studio Code oder PyCharm geöffnet werden.