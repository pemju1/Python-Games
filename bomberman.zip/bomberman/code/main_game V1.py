from queue import Empty
import pygame
from sys import exit

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.player_front_stand = pygame.image.load('graphic\Player\player_front_stand.png').convert_alpha()
        player_front_walk_1 = pygame.image.load('graphic\Player\player_front_walk_1.png').convert_alpha()
        player_front_walk_2 = pygame.image.load('graphic\Player\player_front_walk_2.png').convert_alpha()

        self.player_back_stand = pygame.image.load('graphic\Player\player_back_stand.png').convert_alpha()
        player_back_walk_1 = pygame.image.load('graphic\Player\player_back_walk_1.png').convert_alpha()
        player_back_walk_2 = pygame.image.load('graphic\Player\player_back_walk_2.png').convert_alpha()

        self.player_left_stand = pygame.image.load('graphic\Player\player_left_stand.png').convert_alpha()
        player_left_walk_1 = pygame.image.load('graphic\Player\player_left_walk_1.png').convert_alpha()
        player_left_walk_2 = pygame.image.load('graphic\Player\player_left_walk_2.png').convert_alpha()

        self.player_right_stand = pygame.image.load('graphic\Player\player_right_stand.png').convert_alpha()
        player_right_walk_1 = pygame.image.load('graphic\Player\player_right_walk_1.png').convert_alpha()
        player_right_walk_2 = pygame.image.load('graphic\Player\player_right_walk_2.png').convert_alpha()




        self.player_walk = [[player_front_walk_1, player_front_walk_2],
                            [player_back_walk_1, player_back_walk_2],
                            [player_left_walk_1, player_left_walk_2],
                            [player_right_walk_1, player_right_walk_2]]
        self.player_index_direction = 2
        self.player_index_move_state = 1
        self.image = self.player_walk[self.player_index_direction][self.player_index_move_state]
        self.image = pygame.transform.scale(self.image, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (0,0))

        self.direction = Empty

    def player_input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.rect.y -= 2
            self.direction = 'up'
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.rect.y += 2
            self.direction = 'down'
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.rect.x -= 2
            self.direction = 'left'
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.rect.x += 2
            self.direction = 'right'
        if not keys[pygame.K_UP] and not keys[pygame.K_DOWN] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT] and not keys[pygame.K_w] and not keys[pygame.K_s] and not keys[pygame.K_a] and not keys[pygame.K_d]: 
            self.direction = ''

    def animation(self):
        if self.direction == 'up':
            self.player_index_direction = 1
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[1]):self.player_index_move_state = 0
        if self.direction == 'down':
            self.player_index_direction = 0
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[0]):self.player_index_move_state = 0
        if self.direction == 'left':
            self.player_index_direction = 2
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[2]):self.player_index_move_state = 0
        if self.direction == 'right':
            self.player_index_direction = 3
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[3]):self.player_index_move_state = 0

        self.image = self.player_walk[int(self.player_index_direction)][int(self.player_index_move_state)]
        self.image = pygame.transform.scale(self.image, (grid_size, grid_size))

    def update(self):
        self.player_input()
        self.animation()



def draw():
    wall = pygame.image.load('graphic\Tarain\stone_wall.png').convert_alpha()
    wall = pygame.transform.scale(wall, (grid_size, grid_size))
    wall_rect = wall.get_rect(topleft = (0,0))

    floor = pygame.image.load('graphic/Tarain/floor.png').convert_alpha()
    floor = pygame.transform.scale(floor, (grid_size, grid_size))
    floor_rect = wall.get_rect(topleft = (0,0))

    obstacle = pygame.image.load('graphic\Tarain\obstacle_1.png').convert_alpha()
    obstacle = pygame.transform.scale(obstacle, (grid_size, grid_size))
    obstacle_rect = obstacle.get_rect(topleft = (0,0))

    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 1:
                wall_rect.y = i*grid_size
                wall_rect.x = j*grid_size
                screen.blit(wall, wall_rect)
            if grid[i][j] == 0:
                floor_rect.y = i*grid_size
                floor_rect.x = j*grid_size
                screen.blit(floor, floor_rect)
            if grid[i][j] == 2:
                obstacle_rect.y = i*grid_size
                obstacle_rect.x = j*grid_size
                screen.blit(obstacle, obstacle_rect)

pygame.init()
clock = pygame.time.Clock()

grid_size = 30
grid = [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]


# display surface
screen = pygame.display.set_mode((grid_size*23,grid_size*15))
pygame.display.set_caption('Bomberman')


wall_frame = pygame.image.load('graphic\Tarain\stone_wall.png').convert_alpha()
wall_rect = wall_frame.get_rect(topleft = (0,0))

#Grupe
player = pygame.sprite.GroupSingle()
player.add(Player())


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    draw()
    player.draw(screen)
    player.update()

    pygame.display.update()
    clock.tick(60)    