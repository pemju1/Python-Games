from cgi import test
from queue import Empty
from unittest import TestCase
import pygame, time, os
from sys import exit

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Bilder für Spieler laden
        self.player_front_stand = pygame.image.load(cwd+'graphic\Player\player_front_stand.png').convert_alpha()
        player_front_walk_1 = pygame.image.load(cwd+'graphic\Player\player_front_walk_1.png').convert_alpha()
        player_front_walk_2 = pygame.image.load(cwd+'graphic\Player\player_front_walk_2.png').convert_alpha()

        self.player_back_stand = pygame.image.load(cwd+'graphic\Player\player_back_stand.png').convert_alpha()
        player_back_walk_1 = pygame.image.load(cwd+'graphic\Player\player_back_walk_1.png').convert_alpha()
        player_back_walk_2 = pygame.image.load(cwd+'graphic\Player\player_back_walk_2.png').convert_alpha()

        self.player_left_stand = pygame.image.load(cwd+'graphic\Player\player_left_stand.png').convert_alpha()
        player_left_walk_1 = pygame.image.load(cwd+'graphic\Player\player_left_walk_1.png').convert_alpha()
        player_left_walk_2 = pygame.image.load(cwd+'graphic\Player\player_left_walk_2.png').convert_alpha()

        self.player_right_stand = pygame.image.load(cwd+'graphic\Player\player_right_stand.png').convert_alpha()
        player_right_walk_1 = pygame.image.load(cwd+'graphic\Player\player_right_walk_1.png').convert_alpha()
        player_right_walk_2 = pygame.image.load(cwd+'graphic\Player\player_right_walk_2.png').convert_alpha()



        # Array welches Bewegungsbilder bezüglich Richtung speichert
        self.player_walk = [[player_front_walk_1, player_front_walk_2],
                            [player_back_walk_1, player_back_walk_2],
                            [player_left_walk_1, player_left_walk_2],
                            [player_right_walk_1, player_right_walk_2]]

        self.player_index_direction = 0
        self.player_index_move_state = 0

        # das Bild welches vom Player genutzt wird wird aus dem Array geladen und ein Viereck
        # darum gelegt um es besser bewegen zu können und kolisionen vestzustellen
        self.image = self.player_walk[self.player_index_direction][self.player_index_move_state]
        self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))
        self.rect = self.image.get_rect(topleft = (11*grid_size,7*grid_size))

        self.direction = Empty
        self.lastdirection = Empty
        self.bombcounter = 0
        self.time = 0
        self.lives = 3
        self.gameover = False
        self.unzerstörbar = 0


    def player_input(self):
        # alle Tastenbetätigungen werden eingelesen
        keys = pygame.key.get_pressed()
        # es wird nach einer Taste für die jewailige Richtung gesucht und das Bild in diese richtung bewegt,
        # wenn dadurch etwas berührt wird, das nicht berührt werden soll wird die bewegung anuliert
        # zusätzlich wird in Strings die Bewegungsrichtung gespeichert
        if (keys[pygame.K_UP] or keys[pygame.K_w]) and self.rect.y > 1*grid_size:
            self.rect.y -= 2
            self.lastdirection = ''
            self.direction = 'up'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.y += 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.y += 2

        if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and self.rect.y < 13*grid_size:
            self.rect.y += 2
            self.lastdirection = ''
            self.direction = 'down'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.y -= 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.y -= 2

        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and self.rect.x > 1*grid_size:
            self.rect.x -= 2
            self.lastdirection = ''
            self.direction = 'left'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.x += 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.x += 2

        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and self.rect.x < 21*grid_size:
            self.rect.x += 2
            self.lastdirection = ''
            self.direction = 'right'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.x -= 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.x -= 2

        # wenn keine Bewegung stattfindet wird die letzte Bewegungsrichtung gespeichert um den stehenden Spieler in diese Richtung zu zeigen
        if not keys[pygame.K_UP] and not keys[pygame.K_DOWN] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT] and not keys[pygame.K_w] and not keys[pygame.K_s] and not keys[pygame.K_a] and not keys[pygame.K_d]: 
            if self.direction == 'up': self.lastdirection = 'up'
            if self.direction == 'down': self.lastdirection = 'down'
            if self.direction == 'left': self.lastdirection = 'left'
            if self.direction == 'right': self.lastdirection = 'right'
            self.direction = ''


        if keys[pygame.K_SPACE] and (self.time-time.perf_counter() < -3 or self.bombcounter == 0):
            bomb.add(Bomb())
            self.bombcounter = 1
            global timer
            timer = time.perf_counter()
            self.time = time.perf_counter()


    def animation(self):
        # je nach Bewegungsrichtung wird der jewailige Index geändert damit es zum nächsten Bild wechselt
        # diese Indexerhöung nur langsam, damit das Bild nicht mit jedem Schleifendurchlauf sich ändert
        if self.direction == 'up':
            self.player_index_direction = 1
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[1]):self.player_index_move_state = 0
        if self.direction == 'down':
            self.player_index_direction = 0
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[0]):self.player_index_move_state = 0
        if self.direction == 'left':
            self.player_index_direction = 2
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[2]):self.player_index_move_state = 0
        if self.direction == 'right':
            self.player_index_direction = 3
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[3]):self.player_index_move_state = 0

        # initialisieren des Bildes mit neuem Index plus Größe anpassen
        self.image = self.player_walk[int(self.player_index_direction)][int(self.player_index_move_state)]
        self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))

        # player stand
        if not self.lastdirection == '':
            if self.lastdirection == 'up': self.image = self.player_back_stand
            if self.lastdirection == 'down': self.image = self.player_front_stand
            if self.lastdirection == 'left': self.image = self.player_left_stand
            if self.lastdirection == 'right': self.image = self.player_right_stand

            self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))

    def live_counter(self):
        if pygame.sprite.spritecollideany(player.sprite, fire) and self.unzerstörbar == 0:
            self.lives -= 1
            self.unzerstörbar = 1
            # hearts.empty()
            global lives, heart_ammount
            #heart_ammount = 3
            lives = self.lives

        if timer_fire-time.perf_counter() < -2:
            self.unzerstörbar = 0 

        if self.lives == 0:
            self.gameover = True
            global game_active
            game_active = False

        # wird in der Gameschleife aufgerufen um die darin genannten Funktionen zu aktuakisieren
    def update(self):
        if self.gameover == False:
            self.player_input()
            self.animation()
            self.live_counter()
            global player_x, player_y
            player_x = int((self.rect.x+15)/grid_size)
            player_y = int((self.rect.y+15)/grid_size)
        else:
            if game_active == True:
                self.lives = 3
                self.gameover = False
                self.rect = self.image.get_rect(topleft = (11*grid_size,7*grid_size))

class Bomb(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        bomb_1 = pygame.image.load(cwd+'graphic/Bomb/bomb_1.png').convert_alpha()
        bomb_2 = pygame.image.load(cwd+'graphic/Bomb/bomb_2.png').convert_alpha()
        self.bomb_frames = [bomb_1, bomb_2]
        self.bomb_index = 0
        self.image = self.bomb_frames[int(self.bomb_index)]
        self.image = pygame.transform.scale(self.image, (25, 25))
        self.rect = self.image.get_rect(center = (player_x*grid_size+15,player_y*grid_size+15))
        self.explotion = False

        self.down = True
        self.up = True
        self.left = True
        self.right = True

    def explosion_timer(self):
        if timer-time.perf_counter() < -3:
            global timer_fire
            self.explotion = True
            timer_fire = time.perf_counter()
            self.kill()

    def explotions(self):
        if self.explotion == True:
            global grid

            u = 0
            d = 0
            l = 0 
            r = 0

            grid[int((self.rect.y)/grid_size)][int((self.rect.x)/grid_size)] = 3

            for x in range(3):           

                try: 
                    if grid[int((self.rect.y)/grid_size)][int((self.rect.x+grid_size*(x+1))/grid_size)] == 2: r += 1
                except LookupError: pass #falls das Feld nicht im Index ist wird es übersprungen
                try:
                    if grid[int((self.rect.y)/grid_size)][int((self.rect.x-grid_size*(x+1))/grid_size)] == 2: l += 1 
                except LookupError: pass
                try:
                    if grid[int((self.rect.y+grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] == 2: d += 1
                except LookupError: pass
                try:
                    if grid[int((self.rect.y-grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] == 2: u += 1 
                except LookupError: pass

                if r>= 2: self.right = False
                if l>= 2: self.left = False
                if d>= 2: self.down = False
                if u>= 2: self.up = False

                try:
                    if not grid[int((self.rect.y)/grid_size)][int((self.rect.x+grid_size*(x+1))/grid_size)] == 1 and self.right == True:
                        grid[int((self.rect.y)/grid_size)][int((self.rect.x+grid_size*(x+1))/grid_size)] = 6
                    else: 
                        self.right = False
                        r = 2
                except LookupError: pass

                try:
                    if not grid[int((self.rect.y)/grid_size)][int((self.rect.x-grid_size*(x+1))/grid_size)] == 1 and self.left == True:
                        grid[int((self.rect.y)/grid_size)][int((self.rect.x-grid_size*(x+1))/grid_size)] = 6
                    else: 
                        self.left = False
                        l = 2
                except LookupError: pass

                try:
                    if not grid[int((self.rect.y+grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] == 1 and self.down == True:
                        grid[int((self.rect.y+grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] = 4
                    else: 
                        self.down = False
                        d = 2
                except LookupError: pass

                try:
                    if not grid[int((self.rect.y-grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] == 1 and self.up == True:
                        grid[int((self.rect.y-grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] = 4
                    else: 
                        self.up = False
                        u = 2
                except LookupError: pass

                if r == 1 or (x == 2 and self.right == True):
                    grid[int((self.rect.y)/grid_size)][int((self.rect.x+grid_size*(x+1))/grid_size)] = 7 
                    self.right = False    
                if l == 1 or (x == 2 and self.left == True): 
                    grid[int((self.rect.y)/grid_size)][int((self.rect.x-grid_size*(x+1))/grid_size)] = 8
                    self.left = False 
                if d == 1 or (x == 2 and self.down == True): 
                    grid[int((self.rect.y+grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] = 9
                    self.down = False 
                if u == 1 or (x == 2 and self.up == True): 
                    grid[int((self.rect.y-grid_size*(x+1))/grid_size)][int(self.rect.x/grid_size)] = 5
                    self.up = False 

    def update(self):
        self.explosion_timer()
        self.explotions()

class Fire(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y, type):
        super().__init__()
        if type == 1:
            fire_1 = pygame.image.load(cwd+'graphic\Bomb\explosion_1.png').convert_alpha()
            self.image = pygame.transform.scale(fire_1, (grid_size, grid_size))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

        if type == 2:
            fire_2 = pygame.image.load(cwd+'graphic\Bomb\explosion_3.png').convert_alpha()
            self.image = pygame.transform.scale(fire_2, (grid_size, grid_size))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

        if type == 4:
            fire_2 = pygame.image.load(cwd+'graphic\Bomb\explosion_3.png').convert_alpha()
            self.image = pygame.transform.rotozoom(fire_2, 90, (30/14))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))
            
        if type == 3:
            fire_3 = pygame.image.load(cwd+'graphic\Bomb\explosion_2.png').convert_alpha()
            self.image = pygame.transform.scale(fire_3, (grid_size, grid_size))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))  

        if type == 5:
            fire_3 = pygame.image.load(cwd+'graphic\Bomb\explosion_4.png').convert_alpha()
            self.image = pygame.transform.scale(fire_3, (grid_size, grid_size))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

        if type == 6:
            fire_3 = pygame.image.load(cwd+'graphic\Bomb\explosion_2.png').convert_alpha()
            self.image = pygame.transform.rotozoom(fire_3, 90, (30/14))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

        if type == 7:
            fire_3 = pygame.image.load(cwd+'graphic\Bomb\explosion_5.png').convert_alpha()
            self.image = pygame.transform.scale(fire_3, (grid_size, grid_size))
            self.rect = self.image.get_rect(topleft = (pos_x,pos_y)) 

    def time_shown(self):
        if timer_fire-time.perf_counter() < -1:
            global delete_fire 
            delete_fire = True
            self.kill()
        
    def update(self):
        self.time_shown()

class Wall(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        wall = pygame.image.load(cwd+'graphic\Tarain\stone_wall.png').convert_alpha()
        self.image = pygame.transform.scale(wall, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

class Obstacle(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        obstacle = pygame.image.load(cwd+'graphic\Tarain\obstacle_1.png').convert_alpha()
        self.image = pygame.transform.scale(obstacle, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))
        
    def delete_block(self):
        for i in range(len(x_end_fire)):
            x = x_end_fire[i]
            y = y_end_fire[i]
            if self.rect.y == y and self.rect.x == x:
                self.kill()
            
    def update(self):
        self.delete_block()

class Floor(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        floor = pygame.image.load(cwd+'graphic/Tarain/floor.png').convert_alpha()
        self.image = pygame.transform.scale(floor, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

class Heart(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y,type):
        super().__init__()
        if type == 'red':
            self.image = pygame.image.load(cwd+'graphic\Player\herz_1.png').convert_alpha()
        if type == 'grey':
            self.image = pygame.image.load(cwd+'graphic\Player\herz_2.png').convert_alpha()
        
        self.image = pygame.transform.scale(self.image, (25, 25))
        self.rect = self.image.get_rect(center = (pos_x + grid_size/2,pos_y + grid_size/2))

def Group_add():
    # loopt durch Grid und fügt je nach Zahl in der Gridposition ein passendes Element mit 
    # den richtigen Koordinaten in eine Liste, damit diese gezeichnet werden können
    # mit grid_2 wird überprüft ob eine änderung vorgenommen wurde und ein neues Element der liste hinzugefügt werden muss.
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 1 and not grid_2[i][j] == 1:
                y = i*grid_size
                x = j*grid_size
                wall.add(Wall(x,y))
                grid_2[i][j] = 1
            if grid[i][j] == 2 and not grid_2[i][j] == 2:
                y = i*grid_size
                x = j*grid_size
                obstacle.add(Obstacle(x,y))
                grid_2[i][j] = 2
            if grid[i][j] == 0 and not grid_2[i][j] == 0:
                y = i*grid_size
                x = j*grid_size
                floor.add(Floor(x,y))
                grid_2[i][j] = 0
            #Fire 
            # center part   
            if grid[i][j] == 3 and not grid_2[i][j] == 3:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,1))
                grid_2[i][j] = 3
            # middle part 
            if grid[i][j] == 4 and not grid_2[i][j] == 4:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,2))
                grid_2[i][j] = 4
            if grid[i][j] == 6 and not grid_2[i][j] == 6:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,4))
                grid_2[i][j] = 6
            # end part
            if grid[i][j] == 5 and not grid_2[i][j] == 5:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,3))
                grid_2[i][j] = 5
            if grid[i][j] == 7 and not grid_2[i][j] == 7:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,5))
                grid_2[i][j] = 7
            if grid[i][j] == 8 and not grid_2[i][j] == 8:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,6))
                grid_2[i][j] = 8
            if grid[i][j] == 9 and not grid_2[i][j] == 9:
                y = i*grid_size
                x = j*grid_size
                fire.add(Fire(x,y,7))
                grid_2[i][j] = 9

def Group_add_Hearts():
    global heart_ammount
    if lives == 3:
        hearts.empty()
        heart_ammount = 3
        for x in range(3):
            if heart_ammount > 0:
                hearts.add(Heart(x*grid_size+20*grid_size,15*grid_size,'red'))
                heart_ammount -= 1

    if lives == 2:
        hearts.empty()
        heart_ammount = 3
        for x in range(2):
            if heart_ammount > 0:
                hearts.add(Heart(x*grid_size+20*grid_size,15*grid_size,'red'))
                heart_ammount -= 1
        if heart_ammount == 1:
            hearts.add(Heart(2*grid_size+20*grid_size,15*grid_size,'grey'))
            heart_ammount -= 1

    if lives == 1:
        hearts.empty()
        heart_ammount = 3
        for x in range(1):
            if heart_ammount > 0:
                hearts.add(Heart(x*grid_size+20*grid_size,15*grid_size,'red'))
                heart_ammount -= 1
        for x in range(2):
            if heart_ammount > 0:
                hearts.add(Heart((x+1)*grid_size+20*grid_size,15*grid_size,'grey'))
                heart_ammount -= 1
    
    if lives == 0:
        hearts.empty()
        heart_ammount = 3
        for x in range(3):
            if heart_ammount > 0:
                hearts.add(Heart(x*grid_size+20*grid_size,15*grid_size,'grey'))
                heart_ammount -= 1

def Group_delete():
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 3 and delete_fire == True:
                grid[i][j] = 0
            if grid[i][j] == 4 and delete_fire == True:
                grid[i][j] = 0
            if grid[i][j] == 5 and delete_fire == True:
                grid[i][j] = 0
                y = i*grid_size
                x = j*grid_size
                x_end_fire.append(x)
                y_end_fire.append(y)
            if grid[i][j] == 6 and delete_fire == True:
                grid[i][j] = 0
            if grid[i][j] == 7 and delete_fire == True:
                grid[i][j] = 0
                y = i*grid_size
                x = j*grid_size
                x_end_fire.append(x)
                y_end_fire.append(y)
            if grid[i][j] == 8 and delete_fire == True:
                grid[i][j] = 0
                y = i*grid_size
                x = j*grid_size
                x_end_fire.append(x)
                y_end_fire.append(y)
            if grid[i][j] == 9 and delete_fire == True:
                grid[i][j] = 0
                y = i*grid_size
                x = j*grid_size
                x_end_fire.append(x)
                y_end_fire.append(y)

def display_score():
    current_time = int(pygame.time.get_ticks() / 1000) - start_time
    score_surf = test_font.render(f'Score: {current_time}', False, (128,128,128))
    score_rect = score_surf.get_rect(midleft = (5,15*grid_size+20))
    screen.blit(score_surf, score_rect)
    return current_time

def set_variable_to_standard():
    global lives, x_end_fire, y_end_fire, grid, grid_2, player_x, player_y, bomb_placed, timer, timer_fire, delete_fire, heart_ammount
    lives = 3
    x_end_fire = []
    y_end_fire = []
    grid = [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
                [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
                [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]
    grid_2 = [[99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99]]
    wall.empty()
    obstacle.empty()
    floor.empty()
    fire.empty()
    hearts.empty()
    bomb.empty()
    player_x = 0
    player_y = 0
    bomb_placed = False
    timer = 0
    timer_fire = 0
    delete_fire = False
    heart_ammount = 3


pygame.init()
clock = pygame.time.Clock()

grid_size_player = 28
grid_size = 30
grid = [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]

# zum überprüfen ob eine änderung in "grid" vorgenommen wurde
grid_2 = [[99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99],
        [99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99,99]]

x_end_fire = []
y_end_fire = []

# display surface
screen = pygame.display.set_mode((grid_size*23,grid_size*16))
pygame.display.set_caption('Bomberman')

cwd = os.getcwd()#current working directory
cwd = cwd.replace('\code','')
cwd = cwd+'/'

game_active = True

#Schriftart
test_font = pygame.font.Font(cwd+'font\Pixeltype.ttf', 50)

#Timer
start_time = 0

# Variabeln für die Bombe
player_x = 0
player_y = 0
bomb_placed = False
timer = 0
timer_fire = 0
delete_fire = False

lives = 3
heart_ammount = 3

#Grupe
player = pygame.sprite.GroupSingle() # besondere art von Gruppen für Elemente mit Bildern und Positionen
player.add(Player())
wall = pygame.sprite.Group()
obstacle = pygame.sprite.Group()# zu Begin 200
floor = pygame.sprite.Group()
bomb = pygame.sprite.Group()
fire = pygame.sprite.Group()
hearts = pygame.sprite.Group()


# begin des game loop
while True:
    # erlaupt es das Spiel zu schließen
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN and game_active == False:
            start_time = int(pygame.time.get_ticks() / 1000)
            set_variable_to_standard()
            game_active=True
            Group_add()
            wall.draw(screen)   
            obstacle.draw(screen)
            obstacle.update()
            floor.draw(screen)
            bomb.draw(screen)
            bomb.update()
            fire.draw(screen)
            fire.update()
            score = display_score()
            player.draw(screen)
            player.update()
            Group_add_Hearts()
            hearts.draw(screen)


    if game_active == True:
        screen.fill((33, 99, 20))

        # fügt Elemente in die Gruppen hinzu, die laut grid an der position sein sollen
        Group_add()
        Group_delete()
        #draw malt die Elemente auf den Bildschirm
        wall.draw(screen)   
        obstacle.draw(screen)
        obstacle.update()
        floor.draw(screen)
        bomb.draw(screen)
        bomb.update()
        fire.draw(screen)
        fire.update()
        score = display_score()
        player.draw(screen)
        player.update()
        Group_add_Hearts()
        hearts.draw(screen)         

    pygame.display.update()
    clock.tick(60)    