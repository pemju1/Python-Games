from queue import Empty
import pygame
from sys import exit

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Bilder für Spieler laden
        self.player_front_stand = pygame.image.load('graphic\Player\player_front_stand.png').convert_alpha()
        player_front_walk_1 = pygame.image.load('graphic\Player\player_front_walk_1.png').convert_alpha()
        player_front_walk_2 = pygame.image.load('graphic\Player\player_front_walk_2.png').convert_alpha()

        self.player_back_stand = pygame.image.load('graphic\Player\player_back_stand.png').convert_alpha()
        player_back_walk_1 = pygame.image.load('graphic\Player\player_back_walk_1.png').convert_alpha()
        player_back_walk_2 = pygame.image.load('graphic\Player\player_back_walk_2.png').convert_alpha()

        self.player_left_stand = pygame.image.load('graphic\Player\player_left_stand.png').convert_alpha()
        player_left_walk_1 = pygame.image.load('graphic\Player\player_left_walk_1.png').convert_alpha()
        player_left_walk_2 = pygame.image.load('graphic\Player\player_left_walk_2.png').convert_alpha()

        self.player_right_stand = pygame.image.load('graphic\Player\player_right_stand.png').convert_alpha()
        player_right_walk_1 = pygame.image.load('graphic\Player\player_right_walk_1.png').convert_alpha()
        player_right_walk_2 = pygame.image.load('graphic\Player\player_right_walk_2.png').convert_alpha()



        # Array welches Bewegungsbilder bezüglich Richtung speichert
        self.player_walk = [[player_front_walk_1, player_front_walk_2],
                            [player_back_walk_1, player_back_walk_2],
                            [player_left_walk_1, player_left_walk_2],
                            [player_right_walk_1, player_right_walk_2]]

        self.player_index_direction = 0
        self.player_index_move_state = 0

        # das Bild welches vom Player genutzt wird wird aus dem Array geladen und ein Viereck
        # darum gelegt um es besser bewegen zu können und kolisionen vestzustellen
        self.image = self.player_walk[self.player_index_direction][self.player_index_move_state]
        self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))
        self.rect = self.image.get_rect(topleft = (11*grid_size,7*grid_size))

        self.direction = Empty
        self.lastdirection = Empty

    def player_input(self):
        # alle Tastenbetätigungen werden eingelesen
        keys = pygame.key.get_pressed()
        # es wird nach einer Taste für die jewailige Richtung gesucht und das Bild in diese richtung bewegt,
        # wenn dadurch etwas berührt wird, das nicht berührt werden soll wird die bewegung anuliert
        # zusätzlich wird in Strings die Bewegungsrichtung gespeichert
        if (keys[pygame.K_UP] or keys[pygame.K_w]) and self.rect.y > 1*grid_size:
            self.rect.y -= 2
            self.lastdirection = ''
            self.direction = 'up'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.y += 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.y += 2

        if (keys[pygame.K_DOWN] or keys[pygame.K_s]) and self.rect.y < 13*grid_size:
            self.rect.y += 2
            self.lastdirection = ''
            self.direction = 'down'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.y -= 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.y -= 2

        if (keys[pygame.K_LEFT] or keys[pygame.K_a]) and self.rect.x > 1*grid_size:
            self.rect.x -= 2
            self.lastdirection = ''
            self.direction = 'left'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.x += 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.x += 2

        if (keys[pygame.K_RIGHT] or keys[pygame.K_d]) and self.rect.x < 21*grid_size:
            self.rect.x += 2
            self.lastdirection = ''
            self.direction = 'right'
            # correction
            if pygame.sprite.spritecollideany(player.sprite, wall): self.rect.x -= 2
            if pygame.sprite.spritecollideany(player.sprite, obstacle): self.rect.x -= 2

        # wenn keine Bewegung stattfindet wird die letzte Bewegungsrichtung gespeichert um den stehenden Spieler in diese Richtung zu zeigen
        if not keys[pygame.K_UP] and not keys[pygame.K_DOWN] and not keys[pygame.K_LEFT] and not keys[pygame.K_RIGHT] and not keys[pygame.K_w] and not keys[pygame.K_s] and not keys[pygame.K_a] and not keys[pygame.K_d]: 
            if self.direction == 'up': self.lastdirection = 'up'
            if self.direction == 'down': self.lastdirection = 'down'
            if self.direction == 'left': self.lastdirection = 'left'
            if self.direction == 'right': self.lastdirection = 'right'
            self.direction = ''


    def animation(self):
        # je nach Bewegungsrichtung wird der jewailige Index geändert damit es zum nächsten Bild wechselt
        # diese Indexerhöung nur langsam, damit das Bild nicht mit jedem Schleifendurchlauf sich ändert
        if self.direction == 'up':
            self.player_index_direction = 1
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[1]):self.player_index_move_state = 0
        if self.direction == 'down':
            self.player_index_direction = 0
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[0]):self.player_index_move_state = 0
        if self.direction == 'left':
            self.player_index_direction = 2
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[2]):self.player_index_move_state = 0
        if self.direction == 'right':
            self.player_index_direction = 3
            self.player_index_move_state += 0.2
            if self.player_index_move_state >= len(self.player_walk[3]):self.player_index_move_state = 0

        # initialisieren des Bildes mit neuem Index plus Größe anpassen
        self.image = self.player_walk[int(self.player_index_direction)][int(self.player_index_move_state)]
        self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))

        # player stand
        if not self.lastdirection == '':
            if self.lastdirection == 'up': self.image = self.player_back_stand
            if self.lastdirection == 'down': self.image = self.player_front_stand
            if self.lastdirection == 'left': self.image = self.player_left_stand
            if self.lastdirection == 'right': self.image = self.player_right_stand

            self.image = pygame.transform.scale(self.image, (grid_size_player, grid_size_player))

        # wird in der Gameschleife aufgerufen um die darin genannten Funktionen zu aktuakisieren
    def update(self):
        self.player_input()
        self.animation()

class Wall(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        wall = pygame.image.load('graphic\Tarain\stone_wall.png').convert_alpha()
        self.image = pygame.transform.scale(wall, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

class Obsracle(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        obsracle = pygame.image.load('graphic\Tarain\obstacle_1.png').convert_alpha()
        self.image = pygame.transform.scale(obsracle, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

class Floor(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        floor = pygame.image.load('graphic/Tarain/floor.png').convert_alpha()
        self.image = pygame.transform.scale(floor, (grid_size, grid_size))
        self.rect = self.image.get_rect(topleft = (pos_x,pos_y))

def Group_add():
    # loopt durch Grid und fügt je nach Zahl in der Gridposition ein passendes Element mit 
    # den richtigen Koordinaten in eine Liste, damit diese gezeichnet werden können
    # mit grid_2 wird überprüft ob eine änderung vorgenommen wurde und ein neues Element der liste hinzugefügt werden muss.
    for i in range(len(grid)):
        for j in range(len(grid[i])):
            if grid[i][j] == 1 and not grid_2[i][j] == 1:
                y = i*grid_size
                x = j*grid_size
                wall.add(Wall(x,y))
                grid_2[i][j] = 1
            if grid[i][j] == 2 and not grid_2[i][j] == 2:
                y = i*grid_size
                x = j*grid_size
                obstacle.add(Obsracle(x,y))
                grid_2[i][j] = 2
            if grid[i][j] == 0 and not grid_2[i][j] == 0:
                y = i*grid_size
                x = j*grid_size
                floor.add(Floor(x,y))
                grid_2[i][j] = 0



pygame.init()
clock = pygame.time.Clock()

grid_size_player = 28
grid_size = 30
grid = [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,0,1,0,1,0,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1],
        [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1],
        [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]

# zum überprüfen ob eine änderung in "grid" vorgenommen wurde
grid_2 = [[9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9],
        [9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9]]

# display surface
screen = pygame.display.set_mode((grid_size*23,grid_size*15))
pygame.display.set_caption('Bomberman')

#Grupe
player = pygame.sprite.GroupSingle() # besondere art von Gruppen für Elemente mit Bildern und Positionen
player.add(Player())
wall = pygame.sprite.Group()
obstacle = pygame.sprite.Group()
floor = pygame.sprite.Group()

# begin des game loop
while True:
    # erlaupt es das Spiel zu schließen
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    # fügt Elemente in die Gruppen hinzu, die laut grid an der position sein sollen
    Group_add()

    #draw malt die Elemente auf den Bildschirm
    wall.draw(screen)
    obstacle.draw(screen)
    floor.draw(screen)
    player.draw(screen)
    player.update()

    pygame.display.update()
    clock.tick(60)    