import os, pygame, time

class Heart(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y,type):
        super().__init__()
        if type == 'red':
            self.image = pygame.image.load(cwd+'graphic\Player\herz_1.png').convert_alpha()
        if type == 'grey':
            self.image = pygame.image.load(cwd+'graphic\Player\herz_2.png').convert_alpha()
        
        self.image = pygame.transform.scale(self.image, (25, 25))
        self.rect = self.image.get_rect(center = (pos_x + 30/2,pos_y + 30/2))

pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((400,400))
cwd = os.getcwd()#current working directory
cwd = cwd.replace('\code','')
cwd = cwd+'/'
#cwd = cwd+'1'
print(cwd)


herzen = pygame.sprite.Group()
herzen.add(Heart(0,0,'red'))
herzen.empty()
herzen.add(Heart(0,0,'red'))
herzen.add(Heart(0,0,'red'))
print(len(herzen))

floor = pygame.image.load('C:/Users/samue/OneDrive/Desktop/Python Projekte/pygameGames/bomberman/graphic/Tarain/floor.png').convert_alpha()
floor = pygame.transform.scale(floor, (25, 25))
floor_rect = floor.get_rect(center = (50,50))

stone_wall = pygame.image.load(cwd+'graphic/Tarain/stone_wall.png').convert_alpha()
stone_wall = pygame.transform.scale(stone_wall, (25, 25))
stone_wall_rect = floor.get_rect(center = (0,0))
while True:
    # erlaupt es das Spiel zu schließen
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.fill((94,129,162))
    screen.blit(floor, floor_rect)
    screen.blit(stone_wall, stone_wall_rect)
    pygame.display.update()
    clock.tick(60)